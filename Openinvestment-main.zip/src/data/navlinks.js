export const navLinks = [
    {
        title: 'Overview',
        href: 'overview'
    },
    {
        title: 'Features',
        href: 'features'
    },
    {
        title: 'Integrations',
        href: 'integrations'
    },
]